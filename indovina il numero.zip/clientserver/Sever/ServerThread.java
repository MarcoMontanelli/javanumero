//Importo i package
import java.net.*;
import java.io.*;

   //Creazione di una classe per il Multrithreading
   class ServerThread extends Thread {
     private Socket socket;
     public ServerThread (Socket socket) {
       this.socket = socket;
       
     }

     //esecuzione del Thread sul Socket
     public void run() {
       try {
         DataInputStream is = new DataInputStream(socket.getInputStream());
         DataOutputStream os = new DataOutputStream(socket.getOutputStream());
         int min = 0;
         int max = 0;
         int num =/*(int) ((Math.random() * (max - min)) + min);*/
         0;
         int tentativi = 0;
         boolean finito=false;
         while(true) {
           String userInput = is.readLine();
           if (userInput == null || userInput.equals("QUIT"))
             break;
           os.writeBytes(userInput + '\n');
           if (Integer.parseInt(userInput) == num && finito==false ){
              tentativi++;
               os.writeBytes("hai indovinato in: "+tentativi+ '\n');
                 os.writeBytes(Integer.toString(tentativi));
                finito=true;
           }
           else if (Integer.parseInt(userInput) != num && finito==false ){
            tentativi++;  
            os.writeBytes("Non hai indovinato, riprova"+ '\n');
            os.writeBytes(Integer.toString(tentativi));
           }
           else if (tentativi==5){
              os.writeBytes("Non hai indovinato, hai raggiunto il numero massimo di tentativi, il numero da indovinare era: "+num);
              finito=true;
              /* 
              try {
                sleep(2000);
              } catch (InterruptedException e) {
                e.printStackTrace();
              }
              */
              os.writeBytes(Integer.toString(tentativi));
              os.close();
              is.close();
              socket.close();
           }

         }
         os.close();
         is.close();
         System.out.println("Ricezione una chiamata di chiusura da:\n" + socket + "\n");
         socket.close();
       }
       catch (IOException e) {
         System.out.println("IOException: " + e);
       }
     }
   }

   //Classe Server per attivare la Socket
/*   public class TCPParallelServer {
     public void start() throws Exception {
       ServerSocket serverSocket = new ServerSocket(7777);

       //Ciclo infinito di ascolto dei Client
       while(true) {
         System.out.println("In attesa di chiamate dai Client... ");
         Socket socket = serverSocket.accept();
         System.out.println("Ho ricevuto una chiamata di apertura da:\n" + socket);
         ServerThread serverThread = new ServerThread(socket);
         serverThread.start();
       }
     }

     public static void main (String[] args) throws Exception {
       TCPParallelServer tcpServer = new TCPParallelServer();
       tcpServer.start();
     }
   }
*/